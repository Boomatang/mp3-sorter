# Good Case 02

The files are in the folder with no stucture.
When finished the artist should have two ablums both with one sing in side.
The name of the song should aslo be set.
