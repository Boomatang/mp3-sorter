# Bad Case 02
The folder has files that are not mp3 files.
The mp3 files should be placed in the correct place.
Other file types should be copied into a rework folder with the same sturcue of where it came from.

