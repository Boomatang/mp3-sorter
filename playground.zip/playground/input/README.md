# The Playgound Input
This is a collection of folder and files for testing the scripts. 

For all files that have been moved, they should be deleted for the working folder.
This would be to allow the process to be ran many times on a very large folder set, 100GB+
