# Bad Case 03
The mp3 file does not have all the required data.
- artist
- ablum
- track name

If this is the case the file should be moved to a rework folder.
