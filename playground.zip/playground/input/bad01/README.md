# BAD CASE 01
The songs in the folder have the same song name in the metedata. 
This should result in two albums been created in the results section for that artist. 
The ablum should be set with some kind of prefix.
